import HomePage from "../components/HomePage";

export const routes = [
  {
    path: "/",
    element: <HomePage />,
    exact: true,
  },
  // ... другие маршруты
];
