function Head({ children }) {
  return <header>{children}</header>;
}

export default Head;
