export default function Catalog() {
  return <></>;
}
